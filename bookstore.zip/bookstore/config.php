<?php

define("TITLE", "Sach.vn - Bookstore");
define("DB_HOST", 'localhost');
define("DB_USER", 'root');
define("DB_DATA", 'bookstore');
define("DB_PASS", '');
define("BASE_URL", "http://localhost/bookstore/");
define("AVATAR_DIR", "assets/upload/avatar/");
define("BOOK_DIR", "assets/upload/books/");
define("SESSION_TIMEOUT", 3600);
        
?>
