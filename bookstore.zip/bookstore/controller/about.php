<?php
require_once 'view/about/index.php';
?>