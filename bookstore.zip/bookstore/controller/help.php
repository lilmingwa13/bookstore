<?php
require_once 'view/help/index.php';
?>
