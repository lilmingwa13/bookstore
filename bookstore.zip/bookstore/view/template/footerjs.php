<script src="<?php echo BASE_URL; ?>assets/vendor/jquery.js"></script>
<script src="<?php echo BASE_URL; ?>assets/js/plugins.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/jquery.easing.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/jquery.appear.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/jquery.cookie.js"></script>

<script src="<?php echo BASE_URL; ?>assets/vendor/bootstrap.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/twitterjs/twitter.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/jflickrfeed/jflickrfeed.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/magnific-popup/magnific-popup.js"></script>
<script src="<?php echo BASE_URL; ?>assets/vendor/jquery.validate.js"></script>

<!-- Theme Initializer -->
<script src="<?php echo BASE_URL; ?>assets/js/theme.js"></script>

<!-- Custom JS -->
<script src="<?php echo BASE_URL; ?>assets/js/custom.js"></script>