<div class="container">
    <h1 class="logo">
        <a href="<?php echo BASE_URL ?>">
            <img alt="Porto" width="280" height="78" data-sticky-width="140" data-sticky-height="36" src="<?php echo BASE_URL; ?>assets/img/logo.png">
        </a>
    </h1>

    <nav>
        <ul class="nav nav-pills nav-top">
            <span class="text-danger">Thanh toán trực tuyến - An toàn - Tiện lợi - Tiết kiệm thời gian</span>
        </ul>
    </nav>
    <button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">
        <i class="icon icon-bars"></i>
    </button>
</div>